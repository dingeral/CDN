#!/bin/bash
sudo  apt install  conky hddtemp curl lm-sensors conky-all -y
sudo chmod u+s /usr/sbin/hddtemp 
sudo sensors-detect

cp -fr feed $HOME/.feed
cp conkyrc $HOME/.conkyrc

net=`route | grep default | awk '{print $NF}'`
sed -i "/下载速度/d" $HOME/.conkyrc 
sed -i "/上传速度/d" $HOME/.conkyrc
sed -i "/downspeedgraph/d" $HOME/.conkyrc
echo "下载速度:\$alignr\${downspeed $net} k/s" >> $HOME/.conkyrc
echo "上传速度:\$alignr\${upspeed $net} k/s" >> $HOME/.conkyrc
echo "\${downspeedgraph $net 324D23 77B753}" >> $HOME/.conkyrc

sudo ln -s $HOME/.feed/update.sh /usr/bin/feed
sudo chmod 777 /usr/bin/feed
sudo chmod -R 777 $HOME/.feed/

echo 'sleep 8 && conky &' >> $HOME/.profile
echo 'sleep 4 && sh $HOME/.feed/update.sh &' >> $HOME/.profile

$HOME/.feed/update.sh
conky &>/dev/null &

$HOME/.feed/update.sh -h
