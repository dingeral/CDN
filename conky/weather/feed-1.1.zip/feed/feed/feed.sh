#!/bin/bash
case $1 in
a)
	head -1 $HOME/.feed/lsfile
;;

b)
	head -2 $HOME/.feed/lsfile | tail -1
;;

c)
	tail -2 $HOME/.feed/lsfile
;;
esac
