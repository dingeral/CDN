#!/bin/bash

conf(){
echo ''
echo '看起来需要配置好您所在的城市，否则本工具天气模块会出现异常！'
echo ''
echo '您需要在下面输入您所在地区的中文名称'
echo '如：北京、海淀、通辽 或 您所在县城的名称'
echo ''
stty erase ^H
read -p "输入城市(按Ctrl + C 终止)：" ucs
ucs=`echo $ucs | sed 's/省//g' | sed 's/市//g' | sed 's/县//g' | sed 's/旗//g' | sed 's/区//g' | sed 's/镇//g'`
echo $ucs > $HOME/.feed/config
}


if test "$1" = 'update'; then
	conf;
	echo '会在10分钟内更新'
	echo '终端执行feed 立刻更新，更新后需按ctrl + c 终止程序'
	exit

elif test "$1" = 'remove'; then
	echo '您要卸载本程序吗？？'
	read -n 1 -p '按任意键取消卸载，按Y确认卸载：' rm
	if test "$rm" != 'Y' && test "$rm" != 'y'; then
		exit
	fi
	rm -fr $HOME/.feed $HOME/.conkyrc
	sed -i '/feed\/update.sh/d' $HOME/.profile
	sed -i '/conky/d' $HOME/.profile
	sudo apt remove  conky hddtemp curl lm-sensors conky-all -y
	sudo rm -fr /usr/bin/feed
	killall conky
	echo '卸载完成！！'
	exit
elif test "$1" = '-h'; then
	echo 'feed update	更新天气地区'
	echo 'feed remove	卸载本程序'
	echo 'feed -h		显示本帮主页'
	exit

fi

if [ -f $HOME/.feed/config ]
then
while test ture; do
id=$(curl -s  http://toy1.weather.com.cn/search?cityname=`cat $HOME/.feed/config |tr -d '\n' |od -An -tx1|tr ' ' %` | awk -F'{"ref":"' '{print $2}' | awk -F'~' '{print $1}')
weather=`curl -s http://www.weather.com.cn/weather/$id.shtml | grep -A 11 "（今天）" | grep "p title" | awk -F'"' '{print $2}'`
wd=`curl -s http://www.weather.com.cn/weather/$id.shtml | grep -A 11 "（今天）" | grep "℃</i>" | awk -F'>' '{print $2}' | awk -F'<' '{print $1}'`
wdb=`curl -s http://www.weather.com.cn/weather1d/$id.shtml | grep -A 1 '<!--$forecast_15d_24h_internal-->' | tail -1 | awk '{print $7}' | awk -F'"' '{print $1}'`

kq=`curl -s http://www.weather.com.cn/weather1d/$id.shtml | grep -B 1 '空气污染扩散指数' | head -1 | awk -F'>' '{print $2}' | awk -F'</' '{print $1}'`
cs=`curl -s http://www.weather.com.cn/weather1d/$id.shtml  | grep '当前城市' | awk -F'span> ' '{print $2}' | awk -F' <' '{print $1}'`

fl=`curl -s http://www.weather.com.cn/weather/$id.shtml | grep -A 11 "（今天）" | grep 'span' | awk -F'"' '{print $2}'`
fl1=`curl -s http://www.weather.com.cn/weather/$id.shtml | grep -A 11 "（今天）" | grep '<i>' | tail -1 | awk -F'</' '{print $1}' | awk -F'i>' '{print $2}'`
fl="$fl$fl1"

echo "$wd" > $HOME/.feed/lsfile
echo "$weather   $wdb" >> $HOME/.feed/lsfile
echo "空气质量：$kq      $fl" >> $HOME/.feed/lsfile
echo "更新时间：`date +%m-%d\ %H:%M`      $cs" >> $HOME/.feed/lsfile
sleep 500
done

else
	while test "$ucs" = ''; do
	sleep 0.3
	conf;
	done
	$HOME/.feed/update.sh &>/dev/null &
fi
