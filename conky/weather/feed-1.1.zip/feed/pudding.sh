#!/bin/bash

sed -i '/feed\/update.sh/d' $HOME/.profile
echo 'sleep 4 && sh $HOME/.feed/update.sh &' >> $HOME/.profile